/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.clickgui.screens;

import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import org.lwjgl.glfw.GLFW;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_410;
import net.minecraft.class_4185;
import net.minecraft.class_4280;
import net.minecraft.class_437;
import net.wurstclient.settings.FileSetting;

public final class SelectFileScreen extends class_437
{
	private final class_437 prevScreen;
	private final FileSetting setting;
	
	private ListGui listGui;
	private class_4185 doneButton;
	
	public SelectFileScreen(class_437 prevScreen, FileSetting blockList)
	{
		super(class_2561.method_43470(""));
		this.prevScreen = prevScreen;
		setting = blockList;
	}
	
	@Override
	public void method_25426()
	{
		listGui = new ListGui(field_22787, this, setting.listFiles());
		method_25429(listGui);
		
		method_37063(
			class_4185.method_46430(class_2561.method_43470("Open Folder"), b -> openFolder())
				.method_46434(8, 8, 100, 20).method_46431());
		
		method_37063(class_4185
			.method_46430(class_2561.method_43470("Reset to Defaults"),
				b -> askToConfirmReset())
			.method_46434(field_22789 - 108, 8, 100, 20).method_46431());
		
		doneButton = method_37063(
			class_4185.method_46430(class_2561.method_43470("Done"), b -> done())
				.method_46434(field_22789 / 2 - 102, field_22790 - 48, 100, 20).method_46431());
		
		method_37063(
			class_4185.method_46430(class_2561.method_43470("Cancel"), b -> openPrevScreen())
				.method_46434(field_22789 / 2 + 2, field_22790 - 48, 100, 20).method_46431());
	}
	
	private void openFolder()
	{
		class_156.method_668().method_672(setting.getFolder().toFile());
	}
	
	private void openPrevScreen()
	{
		field_22787.method_1507(prevScreen);
	}
	
	private void done()
	{
		Path path = listGui.getSelectedPath();
		if(path != null)
		{
			String fileName = "" + path.getFileName();
			setting.setSelectedFile(fileName);
		}
		
		openPrevScreen();
	}
	
	private void askToConfirmReset()
	{
		class_2561 title = class_2561.method_43470("Reset Folder");
		
		class_2561 message = class_2561
			.method_43470("This will empty the '" + setting.getFolder().getFileName()
				+ "' folder and then re-generate the default files.\n"
				+ "Are you sure you want to do this?");
		
		field_22787.method_1507(new class_410(this::confirmReset, title, message));
	}
	
	private void confirmReset(boolean confirmed)
	{
		if(confirmed)
			setting.resetFolder();
		
		field_22787.method_1507(SelectFileScreen.this);
	}
	
	@Override
	public boolean method_25404(int keyCode, int scanCode, int modifiers)
	{
		if(keyCode == GLFW.GLFW_KEY_ENTER)
			done();
		else if(keyCode == GLFW.GLFW_KEY_ESCAPE)
			openPrevScreen();
		
		return super.method_25404(keyCode, scanCode, modifiers);
	}
	
	@Override
	public void method_25393()
	{
		doneButton.field_22763 = listGui.method_25334() != null;
	}
	
	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY,
		float partialTicks)
	{
		method_25420(context);
		listGui.method_25394(context, mouseX, mouseY, partialTicks);
		
		context.method_25300(field_22787.field_1772,
			setting.getName(), field_22789 / 2, 12, 0xffffff);
		
		super.method_25394(context, mouseX, mouseY, partialTicks);
		
		if(doneButton.method_25367() && !doneButton.field_22763)
			context.method_51434(field_22793,
				Arrays.asList(class_2561.method_43470("You must first select a file.")),
				mouseX, mouseY);
	}
	
	@Override
	public boolean method_25421()
	{
		return false;
	}
	
	@Override
	public boolean method_25422()
	{
		return false;
	}
	
	private final class Entry
		extends class_4280.class_4281<SelectFileScreen.Entry>
	{
		private final Path path;
		
		public Entry(Path path)
		{
			this.path = Objects.requireNonNull(path);
		}
		
		@Override
		public class_2561 method_37006()
		{
			return class_2561.method_43469("narrator.select",
				"File " + path.getFileName());
		}
		
		@Override
		public boolean method_25402(double mouseX, double mouseY, int button)
		{
			return button == GLFW.GLFW_MOUSE_BUTTON_LEFT;
		}
		
		@Override
		public void method_25343(class_332 context, int index, int y, int x,
			int entryWidth, int entryHeight, int mouseX, int mouseY,
			boolean hovered, float tickDelta)
		{
			class_327 tr = field_22787.field_1772;
			
			String fileName = "" + path.getFileName();
			context.method_25303(tr, fileName, x + 28, y, 0xF0F0F0);
			
			String relPath = "" + field_22787.field_1697.toPath().relativize(path);
			context.method_25303(tr, relPath, x + 28, y + 9, 0xA0A0A0);
		}
	}
	
	private final class ListGui
		extends class_4280<SelectFileScreen.Entry>
	{
		public ListGui(class_310 mc, SelectFileScreen screen,
			List<Path> list)
		{
			super(mc, screen.field_22789, screen.field_22790, 36, screen.field_22790 - 64, 20);
			
			list.stream().map(SelectFileScreen.Entry::new)
				.forEach(this::method_25321);
		}
		
		public Path getSelectedPath()
		{
			SelectFileScreen.Entry selected = method_25334();
			return selected != null ? selected.path : null;
		}
	}
}
