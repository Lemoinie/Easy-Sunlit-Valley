/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.clickgui.screens;

import java.util.List;
import java.util.Objects;

import org.lwjgl.glfw.GLFW;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_410;
import net.minecraft.class_4185;
import net.minecraft.class_4280;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_7923;
import net.wurstclient.settings.ItemListSetting;
import net.wurstclient.util.ItemUtils;
import net.wurstclient.util.RenderUtils;

public final class EditItemListScreen extends class_437
{
	private final class_437 prevScreen;
	private final ItemListSetting itemList;
	
	private ListGui listGui;
	private class_342 itemNameField;
	private class_4185 addButton;
	private class_4185 removeButton;
	private class_4185 doneButton;
	
	private class_1792 itemToAdd;
	
	public EditItemListScreen(class_437 prevScreen, ItemListSetting itemList)
	{
		super(class_2561.method_43470(""));
		this.prevScreen = prevScreen;
		this.itemList = itemList;
	}
	
	@Override
	public void method_25426()
	{
		listGui = new ListGui(field_22787, this, itemList.getItemNames());
		method_25429(listGui);
		
		itemNameField = new class_342(field_22787.field_1772,
			field_22789 / 2 - 152, field_22790 - 55, 150, 18, class_2561.method_43470(""));
		method_25429(itemNameField);
		itemNameField.method_1880(256);
		
		method_37063(
			addButton = class_4185.method_46430(class_2561.method_43470("Add"), b -> {
				itemList.add(itemToAdd);
				field_22787.method_1507(EditItemListScreen.this);
			}).method_46434(field_22789 / 2 - 2, field_22790 - 56, 30, 20).method_46431());
		
		method_37063(removeButton =
			class_4185.method_46430(class_2561.method_43470("Remove Selected"), b -> {
				itemList.remove(itemList.getItemNames()
					.indexOf(listGui.getSelectedBlockName()));
				field_22787.method_1507(EditItemListScreen.this);
			}).method_46434(field_22789 / 2 + 52, field_22790 - 56, 100, 20).method_46431());
		
		method_37063(class_4185.method_46430(class_2561.method_43470("Reset to Defaults"),
			b -> field_22787.method_1507(new class_410(b2 -> {
				if(b2)
					itemList.resetToDefaults();
				field_22787.method_1507(EditItemListScreen.this);
			}, class_2561.method_43470("Reset to Defaults"),
				class_2561.method_43470("Are you sure?"))))
			.method_46434(field_22789 - 108, 8, 100, 20).method_46431());
		
		method_37063(doneButton = class_4185
			.method_46430(class_2561.method_43470("Done"), b -> field_22787.method_1507(prevScreen))
			.method_46434(field_22789 / 2 - 100, field_22790 - 28, 200, 20).method_46431());
	}
	
	@Override
	public boolean method_25402(double mouseX, double mouseY, int mouseButton)
	{
		itemNameField.method_25402(mouseX, mouseY, mouseButton);
		return super.method_25402(mouseX, mouseY, mouseButton);
	}
	
	@Override
	public boolean method_25404(int keyCode, int scanCode, int int_3)
	{
		switch(keyCode)
		{
			case GLFW.GLFW_KEY_ENTER:
			if(addButton.field_22763)
				addButton.method_25306();
			break;
			
			case GLFW.GLFW_KEY_DELETE:
			if(!itemNameField.method_25370())
				removeButton.method_25306();
			break;
			
			case GLFW.GLFW_KEY_ESCAPE:
			doneButton.method_25306();
			break;
			
			default:
			break;
		}
		
		return super.method_25404(keyCode, scanCode, int_3);
	}
	
	@Override
	public void method_25393()
	{
		itemNameField.method_1865();
		
		String nameOrId = itemNameField.method_1882().toLowerCase();
		itemToAdd = ItemUtils.getItemFromNameOrID(nameOrId);
		addButton.field_22763 = itemToAdd != null;
		
		removeButton.field_22763 = listGui.method_25334() != null;
	}
	
	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY,
		float partialTicks)
	{
		class_4587 matrixStack = context.method_51448();
		listGui.method_25394(context, mouseX, mouseY, partialTicks);
		
		context.method_25300(field_22787.field_1772,
			itemList.getName() + " (" + itemList.getItemNames().size() + ")",
			field_22789 / 2, 12, 0xFFFFFF);
		
		matrixStack.method_22903();
		matrixStack.method_46416(0, 0, 300);
		
		itemNameField.method_25394(context, mouseX, mouseY, partialTicks);
		super.method_25394(context, mouseX, mouseY, partialTicks);
		
		matrixStack.method_22903();
		matrixStack.method_46416(-64 + field_22789 / 2 - 152, 0, 0);
		
		if(itemNameField.method_1882().isEmpty() && !itemNameField.method_25370())
		{
			matrixStack.method_22903();
			matrixStack.method_46416(0, 0, 300);
			context.method_25303(field_22787.field_1772, "item name or ID",
				68, field_22790 - 50, 0x808080);
			matrixStack.method_22909();
		}
		
		int border = itemNameField.method_25370() ? 0xFFFFFFFF : 0xFFA0A0A0;
		int black = 0xFF000000;
		
		context.method_25294(48, field_22790 - 56, 64, field_22790 - 36, border);
		context.method_25294(49, field_22790 - 55, 65, field_22790 - 37, black);
		context.method_25294(214, field_22790 - 56, 244, field_22790 - 55, border);
		context.method_25294(214, field_22790 - 37, 244, field_22790 - 36, border);
		context.method_25294(244, field_22790 - 56, 246, field_22790 - 36, border);
		context.method_25294(213, field_22790 - 55, 243, field_22790 - 52, black);
		context.method_25294(213, field_22790 - 40, 243, field_22790 - 37, black);
		context.method_25294(213, field_22790 - 55, 216, field_22790 - 37, black);
		context.method_25294(242, field_22790 - 55, 245, field_22790 - 37, black);
		
		matrixStack.method_22909();
		
		RenderUtils.drawItem(context,
			itemToAdd == null ? class_1799.field_8037 : new class_1799(itemToAdd),
			field_22789 / 2 - 164, field_22790 - 52, false);
		
		matrixStack.method_22909();
	}
	
	@Override
	public boolean method_25421()
	{
		return false;
	}
	
	@Override
	public boolean method_25422()
	{
		return false;
	}
	
	private final class Entry
		extends class_4280.class_4281<EditItemListScreen.Entry>
	{
		private final String itemName;
		
		public Entry(String itemName)
		{
			this.itemName = Objects.requireNonNull(itemName);
		}
		
		@Override
		public class_2561 method_37006()
		{
			class_1792 item = class_7923.field_41178.method_10223(new class_2960(itemName));
			class_1799 stack = new class_1799(item);
			
			return class_2561.method_43469("narrator.select",
				"Item " + getDisplayName(stack) + ", " + itemName + ", "
					+ getIdText(item));
		}
		
		@Override
		public boolean method_25402(double mouseX, double mouseY, int button)
		{
			return button == GLFW.GLFW_MOUSE_BUTTON_LEFT;
		}
		
		@Override
		public void method_25343(class_332 context, int index, int y, int x,
			int entryWidth, int entryHeight, int mouseX, int mouseY,
			boolean hovered, float tickDelta)
		{
			class_1792 item = class_7923.field_41178.method_10223(new class_2960(itemName));
			class_1799 stack = new class_1799(item);
			class_327 tr = field_22787.field_1772;
			
			RenderUtils.drawItem(context, stack, x + 1, y + 1, true);
			context.method_51433(tr, getDisplayName(stack), x + 28, y, 0xF0F0F0,
				false);
			context.method_51433(tr, itemName, x + 28, y + 9, 0xA0A0A0, false);
			context.method_51433(tr, getIdText(item), x + 28, y + 18, 0xA0A0A0,
				false);
		}
		
		private String getDisplayName(class_1799 stack)
		{
			return stack.method_7960() ? "\u00a7ounknown item\u00a7r"
				: stack.method_7964().getString();
		}
		
		private String getIdText(class_1792 item)
		{
			return "ID: " + class_7923.field_41178.method_10206(item);
		}
	}
	
	private final class ListGui
		extends class_4280<EditItemListScreen.Entry>
	{
		public ListGui(class_310 minecraft, EditItemListScreen screen,
			List<String> list)
		{
			super(minecraft, screen.field_22789, screen.field_22790, 32,
				screen.field_22790 - 64, 30);
			
			list.stream().map(EditItemListScreen.Entry::new)
				.forEach(this::method_25321);
		}
		
		public String getSelectedBlockName()
		{
			EditItemListScreen.Entry selected = method_25334();
			return selected != null ? selected.itemName : null;
		}
	}
}
