/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.authlib.GameProfile;
import net.minecraft.class_1291;
import net.minecraft.class_1294;
import net.minecraft.class_1313;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_638;
import net.minecraft.class_742;
import net.minecraft.class_744;
import net.minecraft.class_746;
import net.wurstclient.WurstClient;
import net.wurstclient.event.EventManager;
import net.wurstclient.events.AirStrafingSpeedListener.AirStrafingSpeedEvent;
import net.wurstclient.events.IsPlayerInLavaListener.IsPlayerInLavaEvent;
import net.wurstclient.events.IsPlayerInWaterListener.IsPlayerInWaterEvent;
import net.wurstclient.events.KnockbackListener.KnockbackEvent;
import net.wurstclient.events.PlayerMoveListener.PlayerMoveEvent;
import net.wurstclient.events.PostMotionListener.PostMotionEvent;
import net.wurstclient.events.PreMotionListener.PreMotionEvent;
import net.wurstclient.events.UpdateListener.UpdateEvent;
import net.wurstclient.hack.HackList;
import net.wurstclient.mixinterface.IClientPlayerEntity;

@Mixin(class_746.class)
public class ClientPlayerEntityMixin extends class_742
	implements IClientPlayerEntity
{
	@Shadow
	@Final
	protected class_310 client;
	
	private class_437 tempCurrentScreen;
	private boolean hideNextItemUse;
	
	public ClientPlayerEntityMixin(WurstClient wurst, class_638 world,
		GameProfile profile)
	{
		super(world, profile);
	}
	
	@Inject(at = @At(value = "INVOKE",
		target = "Lnet/minecraft/client/network/AbstractClientPlayerEntity;tick()V",
		ordinal = 0), method = "tick()V")
	private void onTick(CallbackInfo ci)
	{
		EventManager.fire(UpdateEvent.INSTANCE);
	}
	
	/**
	 * This mixin makes AutoSprint's "Omnidirectional Sprint" setting work.
	 */
	@WrapOperation(
		at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/input/Input;hasForwardMovement()Z",
			ordinal = 0),
		method = "tickMovement()V")
	private boolean wrapHasForwardMovement(class_744 input,
		Operation<Boolean> original)
	{
		if(WurstClient.INSTANCE.getHax().autoSprintHack.shouldOmniSprint())
			return input.method_3128().method_35584() > 1e-5F;
		
		return original.call(input);
	}
	
	/**
	 * This mixin runs just before the tickMovement() method calls
	 * isUsingItem(), so that the onIsUsingItem() mixin knows which
	 * call to intercept.
	 */
	@Inject(at = @At(value = "INVOKE",
		target = "Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z",
		ordinal = 0), method = "tickMovement()V")
	private void onTickMovementItemUse(CallbackInfo ci)
	{
		if(WurstClient.INSTANCE.getHax().noSlowdownHack.isEnabled())
			hideNextItemUse = true;
	}
	
	/**
	 * Pretends that the player is not using an item when instructed to do so by
	 * the onTickMovement() mixin.
	 */
	@Inject(at = @At("HEAD"), method = "isUsingItem()Z", cancellable = true)
	private void onIsUsingItem(CallbackInfoReturnable<Boolean> cir)
	{
		if(!hideNextItemUse)
			return;
		
		cir.setReturnValue(false);
		hideNextItemUse = false;
	}
	
	/**
	 * This mixin is injected into a random field access later in the
	 * tickMovement() method to ensure that hideNextItemUse is always reset
	 * after the item use slowdown calculation.
	 */
	@Inject(at = @At(value = "FIELD",
		target = "Lnet/minecraft/client/network/ClientPlayerEntity;ticksToNextAutojump:I",
		opcode = Opcodes.GETFIELD,
		ordinal = 0), method = "tickMovement()V")
	private void afterIsUsingItem(CallbackInfo ci)
	{
		hideNextItemUse = false;
	}
	
	@Inject(at = @At("HEAD"), method = "sendMovementPackets()V")
	private void onSendMovementPacketsHEAD(CallbackInfo ci)
	{
		EventManager.fire(PreMotionEvent.INSTANCE);
	}
	
	@Inject(at = @At("TAIL"), method = "sendMovementPackets()V")
	private void onSendMovementPacketsTAIL(CallbackInfo ci)
	{
		EventManager.fire(PostMotionEvent.INSTANCE);
	}
	
	@Inject(at = @At("HEAD"),
		method = "move(Lnet/minecraft/entity/MovementType;Lnet/minecraft/util/math/Vec3d;)V")
	private void onMove(class_1313 type, class_243 offset, CallbackInfo ci)
	{
		EventManager.fire(PlayerMoveEvent.INSTANCE);
	}
	
	@Inject(at = @At("HEAD"),
		method = "isAutoJumpEnabled()Z",
		cancellable = true)
	private void onIsAutoJumpEnabled(CallbackInfoReturnable<Boolean> cir)
	{
		if(!WurstClient.INSTANCE.getHax().stepHack.isAutoJumpAllowed())
			cir.setReturnValue(false);
	}
	
	/**
	 * When PortalGUI is enabled, this mixin temporarily sets the current screen
	 * to null to prevent the updateNausea() method from closing it.
	 */
	@Inject(at = @At(value = "FIELD",
		target = "Lnet/minecraft/client/MinecraftClient;currentScreen:Lnet/minecraft/client/gui/screen/Screen;",
		opcode = Opcodes.GETFIELD,
		ordinal = 0), method = "updateNausea()V")
	private void beforeUpdateNausea(CallbackInfo ci)
	{
		if(!WurstClient.INSTANCE.getHax().portalGuiHack.isEnabled())
			return;
		
		tempCurrentScreen = client.field_1755;
		client.field_1755 = null;
	}
	
	/**
	 * This mixin restores the current screen as soon as the updateNausea()
	 * method is done looking at it.
	 */
	@Inject(at = @At(value = "FIELD",
		target = "Lnet/minecraft/client/network/ClientPlayerEntity;nauseaIntensity:F",
		opcode = Opcodes.GETFIELD,
		ordinal = 1), method = "updateNausea()V")
	private void afterUpdateNausea(CallbackInfo ci)
	{
		if(tempCurrentScreen == null)
			return;
		
		client.field_1755 = tempCurrentScreen;
		tempCurrentScreen = null;
	}
	
	/**
	 * This mixin allows AutoSprint to enable sprinting even when the player is
	 * too hungry.
	 */
	@Inject(at = @At("HEAD"), method = "canSprint()Z", cancellable = true)
	private void onCanSprint(CallbackInfoReturnable<Boolean> cir)
	{
		if(WurstClient.INSTANCE.getHax().autoSprintHack.shouldSprintHungry())
			cir.setReturnValue(true);
	}
	
	/**
	 * Getter method for what used to be airStrafingSpeed.
	 * Overridden to allow for the speed to be modified by hacks.
	 */
	@Override
	protected float method_49484()
	{
		AirStrafingSpeedEvent event =
			new AirStrafingSpeedEvent(super.method_49484());
		EventManager.fire(event);
		return event.getSpeed();
	}
	
	@Override
	public void method_5750(double x, double y, double z)
	{
		KnockbackEvent event = new KnockbackEvent(x, y, z);
		EventManager.fire(event);
		super.method_5750(event.getX(), event.getY(), event.getZ());
	}
	
	@Override
	public boolean method_5799()
	{
		boolean inWater = super.method_5799();
		IsPlayerInWaterEvent event = new IsPlayerInWaterEvent(inWater);
		EventManager.fire(event);
		
		return event.isInWater();
	}
	
	@Override
	public boolean method_5771()
	{
		boolean inLava = super.method_5771();
		IsPlayerInLavaEvent event = new IsPlayerInLavaEvent(inLava);
		EventManager.fire(event);
		
		return event.isInLava();
	}
	
	@Override
	public boolean method_7325()
	{
		return super.method_7325()
			|| WurstClient.INSTANCE.getHax().freecamHack.isEnabled();
	}
	
	@Override
	public boolean isTouchingWaterBypass()
	{
		return super.method_5799();
	}
	
	@Override
	protected float method_6106()
	{
		return super.method_6106()
			+ WurstClient.INSTANCE.getHax().highJumpHack
				.getAdditionalJumpMotion();
	}
	
	/**
	 * This is the part that makes SafeWalk work.
	 */
	@Override
	protected boolean method_21825()
	{
		return super.method_21825()
			|| WurstClient.INSTANCE.getHax().safeWalkHack.isEnabled();
	}
	
	/**
	 * This mixin allows SafeWalk to sneak visibly when the player is
	 * near a ledge.
	 */
	@Override
	protected class_243 method_18796(class_243 movement, class_1313 type)
	{
		class_243 result = super.method_18796(movement, type);
		
		if(movement != null)
			WurstClient.INSTANCE.getHax().safeWalkHack
				.onClipAtLedge(!movement.equals(result));
		
		return result;
	}
	
	@Override
	public boolean method_6059(class_1291 effect)
	{
		HackList hax = WurstClient.INSTANCE.getHax();
		
		if(effect == class_1294.field_5925
			&& hax.fullbrightHack.isNightVisionActive())
			return true;
		
		if(effect == class_1294.field_5902
			&& hax.noLevitationHack.isEnabled())
			return false;
		
		if(effect == class_1294.field_38092 && hax.antiBlindHack.isEnabled())
			return false;
		
		return super.method_6059(effect);
	}
}
