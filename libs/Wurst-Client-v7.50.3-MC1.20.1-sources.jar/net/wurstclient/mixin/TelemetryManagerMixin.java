/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.minecraft.class_6628;
import net.minecraft.class_7965;
import net.wurstclient.WurstClient;

@Mixin(class_6628.class)
public class TelemetryManagerMixin
{
	@Inject(at = @At("HEAD"),
		method = "getSender()Lnet/minecraft/client/util/telemetry/TelemetrySender;",
		cancellable = true)
	private void onGetSender(CallbackInfoReturnable<class_7965> cir)
	{
		if(!WurstClient.INSTANCE.getOtfs().noTelemetryOtf.isEnabled())
			return;
		
		// Return a dummy that can't actually send anything. :)
		cir.setReturnValue(class_7965.field_41434);
	}
}
