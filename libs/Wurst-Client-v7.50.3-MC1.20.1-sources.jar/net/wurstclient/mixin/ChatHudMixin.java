/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import java.util.List;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.class_2561;
import net.minecraft.class_303;
import net.minecraft.class_310;
import net.minecraft.class_338;
import net.minecraft.class_7469;
import net.minecraft.class_7591;
import net.wurstclient.WurstClient;
import net.wurstclient.event.EventManager;
import net.wurstclient.events.ChatInputListener.ChatInputEvent;

@Mixin(class_338.class)
public class ChatHudMixin
{
	@Shadow
	@Final
	private List<class_303.class_7590> visibleMessages;
	@Shadow
	@Final
	private class_310 client;
	
	@Inject(at = @At("HEAD"),
		method = "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V",
		cancellable = true)
	private void onAddMessage(class_2561 message,
		@Nullable class_7469 signature,
		@Nullable class_7591 indicator, CallbackInfo ci)
	{
		ChatInputEvent event = new ChatInputEvent(message, visibleMessages);
		
		EventManager.fire(event);
		if(event.isCancelled())
		{
			ci.cancel();
			return;
		}
		
		message = event.getComponent();
		indicator = WurstClient.INSTANCE.getOtfs().noChatReportsOtf
			.modifyIndicator(message, signature, indicator);
		
		shadow$logChatMessage(message, indicator);
		shadow$addMessage(message, signature, client.field_1705.method_1738(),
			indicator, false);
		
		ci.cancel();
	}
	
	@Shadow
	private void shadow$logChatMessage(class_2561 message,
		@Nullable class_7591 indicator)
	{
		
	}
	
	@Shadow
	private void shadow$addMessage(class_2561 message,
		@Nullable class_7469 signature, int ticks,
		@Nullable class_7591 indicator, boolean refresh)
	{
		
	}
}
