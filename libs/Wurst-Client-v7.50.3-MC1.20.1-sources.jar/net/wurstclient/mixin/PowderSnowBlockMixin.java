/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.minecraft.class_1297;
import net.minecraft.class_2248;
import net.minecraft.class_2263;
import net.minecraft.class_5635;
import net.wurstclient.WurstClient;

@Mixin(class_5635.class)
public abstract class PowderSnowBlockMixin extends class_2248
	implements class_2263
{
	private PowderSnowBlockMixin(WurstClient wurst, class_2251 settings)
	{
		super(settings);
	}
	
	@Inject(at = @At("HEAD"),
		method = "canWalkOnPowderSnow(Lnet/minecraft/entity/Entity;)Z",
		cancellable = true)
	private static void onCanWalkOnPowderSnow(class_1297 entity,
		CallbackInfoReturnable<Boolean> cir)
	{
		if(!WurstClient.INSTANCE.getHax().snowShoeHack.isEnabled())
			return;
		
		if(entity == WurstClient.MC.field_1724)
			cir.setReturnValue(true);
	}
}
