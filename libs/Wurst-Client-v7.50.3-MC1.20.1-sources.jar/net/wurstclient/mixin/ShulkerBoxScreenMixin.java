/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import net.minecraft.class_1661;
import net.minecraft.class_1733;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_465;
import net.minecraft.class_495;
import net.wurstclient.WurstClient;
import net.wurstclient.hacks.AutoStealHack;

@Mixin(class_495.class)
public abstract class ShulkerBoxScreenMixin
	extends class_465<class_1733>
{
	@Unique
	private final AutoStealHack autoSteal =
		WurstClient.INSTANCE.getHax().autoStealHack;
	
	private ShulkerBoxScreenMixin(WurstClient wurst,
		class_1733 handler, class_1661 inventory, class_2561 title)
	{
		super(handler, inventory, title);
	}
	
	@Override
	public void method_25426()
	{
		super.method_25426();
		
		if(!WurstClient.INSTANCE.isEnabled())
			return;
		
		if(autoSteal.areButtonsVisible())
		{
			method_37063(class_4185
				.method_46430(class_2561.method_43470("Steal"), b -> autoSteal.steal(this, 3))
				.method_46434(field_2776 + field_2792 - 108, field_2800 + 4, 50, 12).method_46431());
			
			method_37063(class_4185
				.method_46430(class_2561.method_43470("Store"), b -> autoSteal.store(this, 3))
				.method_46434(field_2776 + field_2792 - 56, field_2800 + 4, 50, 12).method_46431());
		}
		
		if(autoSteal.isEnabled())
			autoSteal.steal(this, 3);
	}
}
