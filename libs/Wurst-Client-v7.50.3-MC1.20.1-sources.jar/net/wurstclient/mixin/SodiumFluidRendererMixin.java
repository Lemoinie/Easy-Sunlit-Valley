/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.wurstclient.event.EventManager;
import net.wurstclient.events.ShouldDrawSideListener.ShouldDrawSideEvent;

@Pseudo
@Mixin(targets = {
	// < Sodium 0.6.0-beta.1
	"me.jellysquid.mods.sodium.client.render.chunk.compile.pipeline.FluidRenderer",
	// < Sodium 0.4.9
	"me.jellysquid.mods.sodium.client.render.pipeline.FluidRenderer"},
	remap = false)
public class SodiumFluidRendererMixin
{
	/**
	 * This mixin hides and shows fluids when using X-Ray with Sodium installed.
	 */
	@Inject(at = @At("HEAD"), method = "isSideExposed", cancellable = true)
	private void isSideExposed(class_1920 world, int x, int y, int z,
		class_2350 dir, float height, CallbackInfoReturnable<Boolean> cir)
	{
		class_2338 pos = new class_2338(x, y, z);
		class_2680 state = world.method_8320(pos);
		ShouldDrawSideEvent event = new ShouldDrawSideEvent(state, pos);
		EventManager.fire(event);
		
		if(event.isRendered() != null)
			cir.setReturnValue(event.isRendered());
	}
}
