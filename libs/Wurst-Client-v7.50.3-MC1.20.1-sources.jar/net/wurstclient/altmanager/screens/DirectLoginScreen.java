/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.altmanager.screens;

import net.minecraft.class_2561;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.wurstclient.altmanager.LoginException;
import net.wurstclient.altmanager.LoginManager;
import net.wurstclient.altmanager.MicrosoftLoginManager;

public final class DirectLoginScreen extends AltEditorScreen
{
	public DirectLoginScreen(class_437 prevScreen)
	{
		super(prevScreen, class_2561.method_43470("Direct Login"));
	}
	
	@Override
	protected String getDoneButtonText()
	{
		return getPassword().isEmpty() ? "Change Cracked Name"
			: "Login with Password";
	}
	
	@Override
	protected void pressDoneButton()
	{
		String nameOrEmail = getNameOrEmail();
		String password = getPassword();
		
		if(password.isEmpty())
			LoginManager.changeCrackedName(nameOrEmail);
		else
			try
			{
				MicrosoftLoginManager.login(nameOrEmail, password);
				
			}catch(LoginException e)
			{
				try
				{
					LoginManager.login(nameOrEmail, password);
					
				}catch(LoginException e2)
				{
					message = "\u00a7c\u00a7lMicrosoft:\u00a7c "
						+ e.getMessage() + "\n\u00a7c\u00a7lMojang:\u00a7c "
						+ e2.getMessage();
					
					doErrorEffect();
				}
				return;
			}
		
		message = "";
		field_22787.method_1507(new class_442());
	}
}
