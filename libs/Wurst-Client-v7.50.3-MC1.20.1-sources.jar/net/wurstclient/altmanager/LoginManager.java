/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.altmanager;

import java.net.Proxy;
import java.util.Optional;

import com.mojang.authlib.Agent;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.exceptions.AuthenticationException;
import com.mojang.authlib.exceptions.AuthenticationUnavailableException;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication;
import net.minecraft.class_320;
import net.wurstclient.WurstClient;

public enum LoginManager
{
	;
	
	public static void login(String email, String password)
		throws LoginException
	{
		YggdrasilUserAuthentication auth =
			(YggdrasilUserAuthentication)new YggdrasilAuthenticationService(
				Proxy.NO_PROXY, "").createUserAuthentication(Agent.MINECRAFT);
		
		auth.setUsername(email);
		auth.setPassword(password);
		
		try
		{
			auth.logIn();
			
			GameProfile profile = auth.getSelectedProfile();
			String username = profile.getName();
			String uuid = profile.getId().toString();
			String accessToken = auth.getAuthenticatedToken();
			
			class_320 session = new class_320(username, uuid, accessToken,
				Optional.empty(), Optional.empty(), class_320.class_321.field_1988);
			
			WurstClient.IMC.setWurstSession(session);
			
		}catch(AuthenticationUnavailableException e)
		{
			throw new LoginException("Cannot contact authentication server!",
				e);
			
		}catch(AuthenticationException e)
		{
			e.printStackTrace();
			String msg = e.getMessage().toLowerCase();
			
			if(msg.contains("invalid username or password."))
				throw new LoginException("Wrong password! (or shadowbanned)",
					e);
			
			if(msg.contains("account migrated"))
				throw new LoginException("Account migrated to Mojang account.",
					e);
			
			if(msg.contains("migrated"))
				throw new LoginException(
					"Account migrated to Microsoft account.", e);
			
			throw new LoginException("Cannot contact authentication server!",
				e);
			
		}catch(NullPointerException e)
		{
			e.printStackTrace();
			
			throw new LoginException("Wrong password! (or shadowbanned)", e);
		}
	}
	
	public static void changeCrackedName(String newName)
	{
		class_320 session = new class_320(newName, "", "", Optional.empty(),
			Optional.empty(), class_320.class_321.field_1988);
		
		WurstClient.IMC.setWurstSession(session);
	}
}
