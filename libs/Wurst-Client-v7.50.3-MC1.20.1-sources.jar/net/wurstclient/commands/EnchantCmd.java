/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.commands;

import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_7923;
import net.wurstclient.command.CmdError;
import net.wurstclient.command.CmdException;
import net.wurstclient.command.CmdSyntaxError;
import net.wurstclient.command.Command;
import net.wurstclient.util.ChatUtils;
import net.wurstclient.util.ItemUtils;

public final class EnchantCmd extends Command
{
	public EnchantCmd()
	{
		super("enchant", "Enchants an item with everything,\n"
			+ "except for silk touch and curses.", ".enchant");
	}
	
	@Override
	public void call(String[] args) throws CmdException
	{
		if(!MC.field_1724.method_31549().field_7477)
			throw new CmdError("Creative mode only.");
		
		if(args.length > 1)
			throw new CmdSyntaxError();
		
		enchant(getHeldItem(), 127);
		ChatUtils.message("Item enchanted.");
	}
	
	private class_1799 getHeldItem() throws CmdError
	{
		class_1799 stack = MC.field_1724.method_6047();
		
		if(stack.method_7960())
			stack = MC.field_1724.method_6079();
		
		if(stack.method_7960())
			throw new CmdError("There is no item in your hand.");
		
		return stack;
	}
	
	private void enchant(class_1799 stack, int level)
	{
		for(class_1887 enchantment : class_7923.field_41176)
		{
			// Skip curses
			if(enchantment.method_8195())
				continue;
			
			// Skip Silk Touch so it doesn't remove Fortune
			if(enchantment == class_1893.field_9099)
				continue;
			
			// Limit Quick Charge to level 5 so it doesn't break
			if(enchantment == class_1893.field_9098)
			{
				stack.method_7978(enchantment, Math.min(level, 5));
				continue;
			}
			
			ItemUtils.addEnchantment(stack, enchantment, level);
		}
	}
	
	@Override
	public String getPrimaryAction()
	{
		return "Enchant Held Item";
	}
	
	@Override
	public void doPrimaryAction()
	{
		WURST.getCmdProcessor().process("enchant");
	}
}
