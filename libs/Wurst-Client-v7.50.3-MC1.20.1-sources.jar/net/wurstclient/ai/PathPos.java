/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.ai;

import net.minecraft.class_2338;

public class PathPos extends class_2338
{
	private final boolean jumping;
	
	public PathPos(class_2338 pos)
	{
		this(pos, false);
	}
	
	public PathPos(class_2338 pos, boolean jumping)
	{
		super(pos);
		this.jumping = jumping;
	}
	
	public boolean isJumping()
	{
		return jumping;
	}
	
	@Override
	public boolean equals(Object obj)
	{
		if(this == obj)
			return true;
		
		if(!(obj instanceof PathPos))
			return false;
		
		PathPos node = (PathPos)obj;
		
		return method_10263() == node.method_10263() && method_10264() == node.method_10264()
			&& method_10260() == node.method_10260() && isJumping() == node.isJumping();
	}
	
	@Override
	public int hashCode()
	{
		return super.hashCode() * 2 + (isJumping() ? 1 : 0);
	}
}
