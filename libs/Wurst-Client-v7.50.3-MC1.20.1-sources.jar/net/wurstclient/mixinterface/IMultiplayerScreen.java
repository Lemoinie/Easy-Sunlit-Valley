/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixinterface;

import net.minecraft.class_4267;
import net.minecraft.class_642;

public interface IMultiplayerScreen
{
	public class_4267 getServerListSelector();
	
	public void connectToServer(class_642 server);
}
