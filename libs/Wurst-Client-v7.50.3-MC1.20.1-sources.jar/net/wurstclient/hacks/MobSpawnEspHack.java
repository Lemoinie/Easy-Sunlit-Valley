/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.awt.Color;
import java.util.Map.Entry;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1299;
import net.minecraft.class_1317;
import net.minecraft.class_1317.class_1319;
import net.minecraft.class_1921;
import net.minecraft.class_1923;
import net.minecraft.class_1944;
import net.minecraft.class_1948;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_290;
import net.minecraft.class_293.class_5596;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.WurstRenderLayers;
import net.wurstclient.events.PacketInputListener;
import net.wurstclient.events.RenderListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.hacks.mobspawnesp.HitboxCheckSetting;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.ChunkAreaSetting;
import net.wurstclient.settings.ChunkAreaSetting.ChunkArea;
import net.wurstclient.settings.ColorSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;
import net.wurstclient.util.EasyVertexBuffer;
import net.wurstclient.util.RegionPos;
import net.wurstclient.util.RenderUtils;
import net.wurstclient.util.chunk.ChunkSearcher;
import net.wurstclient.util.chunk.ChunkSearcher.Result;
import net.wurstclient.util.chunk.ChunkVertexBufferCoordinator;

@SearchTags({"mob spawn esp", "LightLevelESP", "light level esp",
	"LightLevelOverlay", "light level overlay"})
public final class MobSpawnEspHack extends Hack
	implements UpdateListener, RenderListener
{
	private final ChunkAreaSetting drawDistance =
		new ChunkAreaSetting("Draw distance", "", ChunkArea.A9);
	
	private final ColorSetting nightColor = new ColorSetting("Night color",
		"description.wurst.setting.mobspawnesp.night_color", Color.YELLOW);
	
	private final ColorSetting dayColor = new ColorSetting("Day color",
		"description.wurst.setting.mobspawnesp.day_color", Color.RED);
	
	private final SliderSetting opacity =
		new SliderSetting("Opacity", 0.5, 0, 1, 0.01, ValueDisplay.PERCENTAGE);
	
	private final CheckboxSetting depthTest =
		new CheckboxSetting("Depth test", true);
	
	private final HitboxCheckSetting hitboxCheck = new HitboxCheckSetting();
	
	private final ChunkVertexBufferCoordinator coordinator =
		new ChunkVertexBufferCoordinator(this::isSpawnable, class_5596.field_27377,
			class_290.field_29337, this::buildBuffer, drawDistance);
	
	private int cachedDayColor;
	private int cachedNightColor;
	
	public MobSpawnEspHack()
	{
		super("MobSpawnESP");
		setCategory(Category.RENDER);
		addSetting(drawDistance);
		addSetting(nightColor);
		addSetting(dayColor);
		addSetting(opacity);
		addSetting(depthTest);
		addSetting(hitboxCheck);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(UpdateListener.class, this);
		EVENTS.add(PacketInputListener.class, coordinator);
		EVENTS.add(RenderListener.class, this);
		
		cachedDayColor = dayColor.getColorI();
		cachedNightColor = nightColor.getColorI();
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
		EVENTS.remove(PacketInputListener.class, coordinator);
		EVENTS.remove(RenderListener.class, this);
		
		coordinator.reset();
	}
	
	@Override
	public void onUpdate()
	{
		if(dayColor.getColorI() != cachedDayColor
			|| nightColor.getColorI() != cachedNightColor)
		{
			cachedDayColor = dayColor.getColorI();
			cachedNightColor = nightColor.getColorI();
			coordinator.reset();
		}
		
		coordinator.update();
	}
	
	@Override
	public void onRender(class_4587 matrixStack, float partialTicks)
	{
		RenderSystem.setShaderColor(1, 1, 1, opacity.getValueF());
		class_1921 layer = WurstRenderLayers.getLines(depthTest.isChecked());
		
		for(Entry<class_1923, EasyVertexBuffer> entry : coordinator.getBuffers())
		{
			RegionPos region = RegionPos.of(entry.getKey());
			
			matrixStack.method_22903();
			RenderUtils.applyRegionalRenderOffset(matrixStack, region);
			
			entry.getValue().draw(matrixStack, layer);
			
			matrixStack.method_22909();
		}
		
		RenderSystem.setShaderColor(1, 1, 1, 1);
	}
	
	private boolean isSpawnable(class_2338 pos, class_2680 state)
	{
		// Check for solid blocks, fluids, redstone, prevent_spawning tags, etc.
		// See SpawnHelper.canSpawn(Location, WorldView, BlockPos,
		// EntityType<?>)
		class_1319 location = class_1317.method_6159(class_1299.field_6046);
		if(!class_1948.method_8660(location, MC.field_1687, pos, class_1299.field_6046))
			return false;
		
		// Check for hitbox collisions
		if(!hitboxCheck.isSpaceEmpty(pos))
			return false;
		
		// Check block light level
		return MC.field_1687.method_8314(class_1944.field_9282, pos) < 1;
	}
	
	private void buildBuffer(class_4588 buffer, ChunkSearcher searcher,
		Iterable<Result> results)
	{
		RegionPos region = RegionPos.of(searcher.getPos());
		
		for(Result result : results)
		{
			if(searcher.isInterrupted())
				return;
			
			drawCross(buffer, result.pos(), region);
		}
	}
	
	private void drawCross(class_4588 buffer, class_2338 pos,
		RegionPos region)
	{
		float x1 = pos.method_10263() - region.x();
		float x2 = x1 + 1;
		float y = pos.method_10264() + 0.01F;
		float z1 = pos.method_10260() - region.z();
		float z2 = z1 + 1;
		
		int color = MC.field_1687.method_8314(class_1944.field_9284, pos) < 8
			? cachedDayColor : cachedNightColor;
		
		buffer.method_22912(x1, y, z1).method_39415(color).method_22914(1, 0, 1).method_1344();
		buffer.method_22912(x2, y, z2).method_39415(color).method_22914(1, 0, 1).method_1344();
		buffer.method_22912(x2, y, z1).method_39415(color).method_22914(-1, 0, 1).method_1344();
		buffer.method_22912(x1, y, z2).method_39415(color).method_22914(-1, 0, 1).method_1344();
	}
}
