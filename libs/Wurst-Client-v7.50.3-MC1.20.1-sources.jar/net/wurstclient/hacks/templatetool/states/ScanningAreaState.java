/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.templatetool.states;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.wurstclient.hacks.TemplateToolHack;
import net.wurstclient.hacks.templatetool.TemplateToolState;
import net.wurstclient.util.BlockUtils;
import net.wurstclient.util.BoxBackports;
import net.wurstclient.util.RenderUtils;

public final class ScanningAreaState extends TemplateToolState
{
	private int totalBlocks;
	private int blocksPerTick;
	private Iterator<class_2338> iterator;
	private int scannedBlocks;
	private float progress;
	
	@Override
	public void onEnter(TemplateToolHack hack)
	{
		class_2338 start = hack.getStartPos();
		class_2338 end = hack.getEndPos();
		int lengthX = Math.abs(start.method_10263() - end.method_10263()) + 1;
		int lengthY = Math.abs(start.method_10264() - end.method_10264()) + 1;
		int lengthZ = Math.abs(start.method_10260() - end.method_10260()) + 1;
		totalBlocks = lengthX * lengthY * lengthZ;
		blocksPerTick = class_3532.method_15340(totalBlocks / 30, 1, 1024);
		iterator = BlockUtils.getAllInBox(start, end).iterator();
	}
	
	@Override
	public void onUpdate(TemplateToolHack hack)
	{
		for(int i = 0; i < blocksPerTick && iterator.hasNext(); i++)
		{
			scannedBlocks++;
			class_2338 pos = iterator.next();
			class_2680 state = BlockUtils.getState(pos);
			
			if(!state.method_45474())
				hack.getNonEmptyBlocks().put(pos, state);
		}
		
		progress = scannedBlocks / (float)totalBlocks;
		
		if(!iterator.hasNext())
			hack.setState(new SelectOriginState());
	}
	
	@Override
	public void onRender(TemplateToolHack hack, class_4587 matrixStack,
		float partialTicks)
	{
		int black = 0x80000000;
		int green15 = 0x2600FF00;
		int green30 = 0x4D00FF00;
		
		// Draw recently scanned blocks
		LinkedHashMap<class_2338, class_2680> blocks = hack.getNonEmptyBlocks();
		int offset = Math.max(0, blocks.size() - blocksPerTick);
		List<class_238> boxes = blocks.keySet().stream().skip(offset)
			.map(pos -> new class_238(pos).method_1014(0.005)).toList();
		
		RenderUtils.drawOutlinedBoxes(matrixStack, boxes, black, true);
		RenderUtils.drawSolidBoxes(matrixStack, boxes, green15, true);
		
		// Draw scanner
		class_2338 start = hack.getStartPos();
		class_2338 end = hack.getEndPos();
		class_238 bounds = BoxBackports.enclosing(start, end).method_1011(1 / 16.0);
		double scannerX = class_3532.method_16436(progress, bounds.field_1323, bounds.field_1320);
		class_238 scanner = bounds.method_35574(scannerX).method_35577(scannerX);
		
		RenderUtils.drawOutlinedBox(matrixStack, scanner, black, true);
		RenderUtils.drawSolidBox(matrixStack, scanner, green30, true);
	}
	
	@Override
	protected String getMessage(TemplateToolHack hack)
	{
		return "Scanning area...";
	}
}
