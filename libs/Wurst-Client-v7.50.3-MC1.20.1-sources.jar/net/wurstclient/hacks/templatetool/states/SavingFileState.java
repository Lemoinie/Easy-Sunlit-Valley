/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.templatetool.states;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_5250;
import net.wurstclient.hacks.TemplateToolHack;
import net.wurstclient.hacks.templatetool.TemplateToolState;
import net.wurstclient.util.BlockUtils;
import net.wurstclient.util.ChatUtils;
import net.wurstclient.util.json.JsonUtils;

public final class SavingFileState extends TemplateToolState
{
	@Override
	protected String getMessage(TemplateToolHack hack)
	{
		return "Saving file...";
	}
	
	@Override
	public void onEnter(TemplateToolHack hack)
	{
		JsonObject json = hack.areBlockTypesEnabled() ? createV2Json(hack)
			: createV1Json(hack);
		
		// Save the file
		try(PrintWriter save = new PrintWriter(new FileWriter(hack.getFile())))
		{
			save.print(JsonUtils.GSON.toJson(json));
			
		}catch(IOException e)
		{
			e.printStackTrace();
			ChatUtils.error("File could not be saved.");
			hack.setEnabled(false);
			return;
		}
		
		// Show success message
		class_5250 message = class_2561.method_43470("Saved template as ");
		class_2558 event = new class_2558(class_2558.class_2559.field_11746,
			hack.getFile().getParentFile().getAbsolutePath());
		class_5250 link = class_2561.method_43470(hack.getFile().getName())
			.method_27694(s -> s.method_30938(true).method_10958(event));
		message.method_10852(link);
		ChatUtils.component(message);
		
		hack.setEnabled(false);
	}
	
	private JsonObject createV2Json(TemplateToolHack hack)
	{
		JsonObject json = new JsonObject();
		json.addProperty("version", 2);
		
		class_2350 front = MC.field_1724.method_5735();
		class_2338 origin = hack.getOriginPos();
		
		JsonArray jsonBlocks = new JsonArray();
		for(class_2338 pos : hack.getSortedBlocks())
		{
			class_2680 state = hack.getNonEmptyBlocks().get(pos);
			if(state == null)
				throw new IllegalStateException("Block at " + pos
					+ " exists in sortedBlocks but not in nonEmptyBlocks.");
			
			JsonObject jsonBlock = new JsonObject();
			jsonBlock.addProperty("block",
				BlockUtils.getName(state.method_26204()));
			
			JsonArray jsonPos = new JsonArray();
			pos = toTemplatePos(pos, origin, front);
			jsonPos.add(pos.method_10263());
			jsonPos.add(pos.method_10264());
			jsonPos.add(pos.method_10260());
			jsonBlock.add("pos", jsonPos);
			
			jsonBlocks.add(jsonBlock);
		}
		json.add("blocks", jsonBlocks);
		return json;
	}
	
	private JsonObject createV1Json(TemplateToolHack hack)
	{
		JsonObject json = new JsonObject();
		json.addProperty("version", 1);
		
		class_2350 front = MC.field_1724.method_5735();
		class_2338 origin = hack.getOriginPos();
		
		JsonArray jsonBlocks = new JsonArray();
		for(class_2338 pos : hack.getSortedBlocks())
		{
			JsonArray jsonPos = new JsonArray();
			pos = toTemplatePos(pos, origin, front);
			jsonPos.add(pos.method_10263());
			jsonPos.add(pos.method_10264());
			jsonPos.add(pos.method_10260());
			jsonBlocks.add(jsonPos);
		}
		json.add("blocks", jsonBlocks);
		return json;
	}
	
	private class_2338 toTemplatePos(class_2338 pos, class_2338 origin,
		class_2350 front)
	{
		class_2338 translated = pos.method_10059(origin);
		class_2350 left = front.method_10160();
		
		int leftDist = translated.method_10263() * left.method_10148()
			+ translated.method_10260() * left.method_10165();
		int upDist = translated.method_10264();
		int frontDist = translated.method_10263() * front.method_10148()
			+ translated.method_10260() * front.method_10165();
		
		return new class_2338(leftDist, upDist, frontDist);
	}
}
