/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.templatetool.states;

import java.util.ArrayDeque;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.TreeSet;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.wurstclient.hacks.TemplateToolHack;
import net.wurstclient.hacks.templatetool.TemplateToolState;
import net.wurstclient.util.BoxBackports;
import net.wurstclient.util.RenderUtils;

public final class CreatingTemplateState extends TemplateToolState
{
	private int totalBlocks;
	private int blocksPerTick;
	private float progress;
	private ArrayDeque<class_2338> unsortedBlocks;
	private TreeSet<class_2338> sortingHelper;
	private final ArrayDeque<class_2338> last1024Added = new ArrayDeque<>();
	
	@Override
	public void onEnter(TemplateToolHack hack)
	{
		totalBlocks = hack.getNonEmptyBlocks().size();
		blocksPerTick = class_3532.method_15340(totalBlocks / 15, 1, 1024);
		
		unsortedBlocks = new ArrayDeque<>(hack.getNonEmptyBlocks().keySet());
		
		class_2338 origin = hack.getOriginPos();
		sortingHelper = new TreeSet<>(Comparator
			.<class_2338> comparingDouble(pos -> pos.method_10262(origin))
			.thenComparing(pos -> pos));
	}
	
	@Override
	public void onUpdate(TemplateToolHack hack)
	{
		// Pass 1: sort by distance from origin
		if(!unsortedBlocks.isEmpty())
		{
			for(int i = 0; i < blocksPerTick && !unsortedBlocks.isEmpty(); i++)
				sortingHelper.add(unsortedBlocks.removeLast());
			
			progress = sortingHelper.size() / (float)totalBlocks;
			return;
		}
		
		// Set the closest-to-origin block as the first block
		LinkedHashSet<class_2338> sortedBlocks = hack.getSortedBlocks();
		if(sortedBlocks.isEmpty() && !sortingHelper.isEmpty())
		{
			class_2338 first = sortingHelper.first();
			sortedBlocks.add(first);
			last1024Added.addLast(first);
			sortingHelper.remove(first);
		}
		
		// Pass 2: walk from the first block until no blocks are left
		for(int i = 0; i < blocksPerTick && !sortingHelper.isEmpty(); i++)
		{
			class_2338 current = sortingHelper.first();
			double dCurrent = Double.MAX_VALUE;
			
			for(class_2338 pos : sortingHelper)
			{
				double dPos = last1024Added.getLast().method_10262(pos);
				if(dPos >= dCurrent)
					continue;
				
				for(class_2350 side : class_2350.values())
				{
					class_2338 next = pos.method_10093(side);
					if(!sortedBlocks.contains(next))
						continue;
					
					current = pos;
					dCurrent = dPos;
				}
			}
			
			sortedBlocks.add(current);
			last1024Added.addLast(current);
			sortingHelper.remove(current);
		}
		
		progress = sortingHelper.size() / (float)totalBlocks;
		if(sortedBlocks.size() == totalBlocks)
			hack.setState(new ChooseNameState());
		
		while(last1024Added.size() > 1024)
			last1024Added.removeFirst();
	}
	
	@Override
	public void onRender(TemplateToolHack hack, class_4587 matrixStack,
		float partialTicks)
	{
		int black = 0x80000000;
		int green30 = 0x4D00FF00;
		
		class_2338 start = hack.getStartPos();
		class_2338 end = hack.getEndPos();
		class_238 bounds = BoxBackports.enclosing(start, end).method_1011(1 / 16.0);
		
		// Draw scanner
		double scannerX = class_3532.method_16436(progress, bounds.field_1323, bounds.field_1320);
		class_238 scanner = bounds.method_35574(scannerX).method_35577(scannerX);
		RenderUtils.drawOutlinedBox(matrixStack, scanner, black, true);
		RenderUtils.drawSolidBox(matrixStack, scanner, green30, true);
		
		// Draw recently sorted blocks
		List<class_238> boxes = last1024Added.stream()
			.map(pos -> new class_238(pos).method_1011(1 / 16.0)).limit(1024).toList();
		RenderUtils.drawOutlinedBoxes(matrixStack, boxes, black, false);
	}
	
	@Override
	protected String getMessage(TemplateToolHack hack)
	{
		return "Creating template...";
	}
}
