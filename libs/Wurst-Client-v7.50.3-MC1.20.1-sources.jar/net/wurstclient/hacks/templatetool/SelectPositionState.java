/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.templatetool;

import org.lwjgl.glfw.GLFW;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_3675;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.wurstclient.hacks.TemplateToolHack;
import net.wurstclient.util.RenderUtils;

public abstract class SelectPositionState extends TemplateToolState
{
	private class_2338 crosshairBlock;
	
	@Override
	public final void onUpdate(TemplateToolHack hack)
	{
		crosshairBlock = getCrosshairBlock();
		
		if(MC.field_1690.field_1904.method_1434() && crosshairBlock != null)
		{
			setSelectedPos(hack, crosshairBlock);
			return;
		}
		
		if(isPressingEnter() && getSelectedPos(hack) != null)
			hack.setState(getNextState());
	}
	
	private class_2338 getCrosshairBlock()
	{
		if(!(MC.field_1765 instanceof class_3965 bHitResult))
			return null;
		
		class_2338 pos = bHitResult.method_17777();
		if(MC.field_1690.field_1832.method_1434())
			pos = pos.method_10093(bHitResult.method_17780());
		
		return pos;
	}
	
	private boolean isPressingEnter()
	{
		return class_3675.method_15987(MC.method_22683().method_4490(),
			GLFW.GLFW_KEY_ENTER);
	}
	
	@Override
	public void onRender(TemplateToolHack hack, class_4587 matrixStack,
		float partialTicks)
	{
		if(crosshairBlock == null)
			return;
		
		class_238 box = new class_238(crosshairBlock).method_1011(1 / 16.0);
		int black = 0x80000000;
		int gray = 0x26404040;
		RenderUtils.drawOutlinedBox(matrixStack, box, black, false);
		RenderUtils.drawSolidBox(matrixStack, box, gray, false);
	}
	
	@Override
	protected final String getMessage(TemplateToolHack hack)
	{
		if(getSelectedPos(hack) != null)
			return "Press enter to confirm, or select a different position.";
		
		return getDefaultMessage();
	}
	
	protected abstract String getDefaultMessage();
	
	protected abstract class_2338 getSelectedPos(TemplateToolHack hack);
	
	protected abstract void setSelectedPos(TemplateToolHack hack, class_2338 pos);
	
	protected abstract TemplateToolState getNextState();
}
