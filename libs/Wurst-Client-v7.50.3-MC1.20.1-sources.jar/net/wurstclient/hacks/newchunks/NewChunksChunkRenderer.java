/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.newchunks;

import java.util.Set;
import net.minecraft.class_1921;
import net.minecraft.class_1923;
import net.minecraft.class_4588;

public interface NewChunksChunkRenderer
{
	public void buildBuffer(class_4588 buffer, Set<class_1923> chunks,
		int drawDistance);
	
	public class_1921 getLayer();
}
