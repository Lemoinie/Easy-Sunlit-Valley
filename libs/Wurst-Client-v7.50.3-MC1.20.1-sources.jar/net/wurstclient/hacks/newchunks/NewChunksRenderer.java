/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.newchunks;

import java.util.function.Consumer;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1921;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.wurstclient.settings.ColorSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.util.BufferWithLayer;
import net.wurstclient.util.RenderUtils;

public final class NewChunksRenderer
{
	private final BufferWithLayer[] vertexBuffers = new BufferWithLayer[4];
	
	private final SliderSetting altitude;
	private final SliderSetting opacity;
	private final ColorSetting newChunksColor;
	private final ColorSetting oldChunksColor;
	
	public NewChunksRenderer(SliderSetting altitude, SliderSetting opacity,
		ColorSetting newChunksColor, ColorSetting oldChunksColor)
	{
		this.altitude = altitude;
		this.opacity = opacity;
		this.newChunksColor = newChunksColor;
		this.oldChunksColor = oldChunksColor;
	}
	
	public void updateBuffer(int i, class_1921 layer,
		Consumer<class_4588> callback)
	{
		vertexBuffers[i] = BufferWithLayer.createAndUpload(layer, callback);
	}
	
	public void closeBuffers()
	{
		for(int i = 0; i < vertexBuffers.length; i++)
		{
			if(vertexBuffers[i] == null)
				continue;
			
			vertexBuffers[i].close();
			vertexBuffers[i] = null;
		}
	}
	
	public void render(class_4587 matrixStack, float partialTicks)
	{
		matrixStack.method_22903();
		RenderUtils.applyRegionalRenderOffset(matrixStack);
		
		float alpha = opacity.getValueF();
		double altitudeD = altitude.getValue();
		
		for(int i = 0; i < vertexBuffers.length; i++)
		{
			BufferWithLayer buffer = vertexBuffers[i];
			if(buffer == null)
				continue;
			
			matrixStack.method_22903();
			if(i == 0 || i == 2)
				matrixStack.method_22904(0, altitudeD, 0);
			
			if(i < 2)
				newChunksColor.setAsShaderColor(alpha);
			else
				oldChunksColor.setAsShaderColor(alpha);
			
			buffer.draw(matrixStack);
			
			matrixStack.method_22909();
		}
		
		matrixStack.method_22909();
		
		RenderSystem.setShaderColor(1, 1, 1, 1);
	}
}
