/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.newchunks;

import java.util.Set;
import net.minecraft.class_1921;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_4588;
import net.wurstclient.WurstRenderLayers;
import net.wurstclient.util.RegionPos;
import net.wurstclient.util.RenderUtils;

public final class NewChunksSquareRenderer implements NewChunksChunkRenderer
{
	@Override
	public void buildBuffer(class_4588 buffer, Set<class_1923> chunks,
		int drawDistance)
	{
		class_1923 camChunkPos = new class_1923(RenderUtils.getCameraBlockPos());
		RegionPos region = RegionPos.of(camChunkPos);
		
		for(class_1923 chunkPos : chunks)
		{
			if(chunkPos.method_24022(camChunkPos) > drawDistance)
				continue;
			
			class_2338 blockPos =
				chunkPos.method_35231(-region.x(), 0, -region.z());
			float x1 = blockPos.method_10263() + 0.5F;
			float x2 = x1 + 15;
			float z1 = blockPos.method_10260() + 0.5F;
			float z2 = z1 + 15;
			int color = 0xFFFFFFFF;
			
			buffer.method_22912(x1, 0, z1).method_39415(color).method_1344();
			buffer.method_22912(x2, 0, z1).method_39415(color).method_1344();
			buffer.method_22912(x2, 0, z2).method_39415(color).method_1344();
			buffer.method_22912(x1, 0, z2).method_39415(color).method_1344();
		}
	}
	
	@Override
	public class_1921 getLayer()
	{
		return WurstRenderLayers.ESP_QUADS_NO_CULLING;
	}
}
