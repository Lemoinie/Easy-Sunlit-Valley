/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.autofish;

import net.minecraft.class_1536;
import net.minecraft.class_243;

public record FishingSpot(PositionAndRotation input, class_243 bobberPos,
	boolean openWater)
{
	public FishingSpot(PositionAndRotation input, class_1536 bobber)
	{
		this(input, bobber.method_19538(), bobber.method_26088());
	}
}
