/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.autofish;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.wurstclient.util.Rotation;

public record PositionAndRotation(class_243 pos, Rotation rotation)
{
	public PositionAndRotation(class_1297 entity)
	{
		this(entity.method_19538(),
			Rotation.wrapped(entity.method_36454(), entity.method_36455()));
	}
	
	public boolean isNearlyIdenticalTo(PositionAndRotation other)
	{
		return pos.method_1022(other.pos) < 0.5
			&& rotation.getAngleTo(other.rotation) < 5;
	}
	
	public double differenceTo(PositionAndRotation other)
	{
		return pos.method_1022(other.pos)
			+ rotation.getAngleTo(other.rotation) / 100;
	}
}
