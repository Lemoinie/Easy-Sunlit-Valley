/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.awt.Color;
import java.util.Comparator;
import java.util.function.ToDoubleFunction;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_746;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.GUIRenderListener;
import net.wurstclient.events.RenderListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.ColorSetting;
import net.wurstclient.settings.EnumSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;
import net.wurstclient.settings.filterlists.EntityFilterList;
import net.wurstclient.util.EntityUtils;
import net.wurstclient.util.RenderUtils;
import net.wurstclient.util.RotationUtils;

@SearchTags({"bow aimbot"})
public final class BowAimbotHack extends Hack
	implements UpdateListener, RenderListener, GUIRenderListener
{
	private final EnumSetting<Priority> priority = new EnumSetting<>("Priority",
		"Determines which entity will be attacked first.\n"
			+ "\u00a7lDistance\u00a7r - Attacks the closest entity.\n"
			+ "\u00a7lAngle\u00a7r - Attacks the entity that requires the least head movement.\n"
			+ "\u00a7lAngle+Dist\u00a7r - A hybrid of Angle and Distance. This is usually the best at figuring out what you want to aim at.\n"
			+ "\u00a7lHealth\u00a7r - Attacks the weakest entity.",
		Priority.values(), Priority.ANGLE_DIST);
	
	private final SliderSetting predictMovement = new SliderSetting(
		"Predict movement",
		"Controls the strength of BowAimbot's movement prediction algorithm.",
		0.2, 0, 2, 0.01, ValueDisplay.PERCENTAGE);
	
	private final EntityFilterList entityFilters =
		EntityFilterList.genericCombat();
	
	private final ColorSetting color = new ColorSetting("ESP color",
		"Color of the box that BowAimbot draws around the target.", Color.RED);
	
	private class_1297 target;
	private float velocity;
	
	public BowAimbotHack()
	{
		super("BowAimbot");
		
		setCategory(Category.COMBAT);
		addSetting(priority);
		addSetting(predictMovement);
		
		entityFilters.forEach(this::addSetting);
		
		addSetting(color);
	}
	
	@Override
	protected void onEnable()
	{
		// disable conflicting hacks
		WURST.getHax().excavatorHack.setEnabled(false);
		WURST.getHax().templateToolHack.setEnabled(false);
		
		// register event listeners
		EVENTS.add(GUIRenderListener.class, this);
		EVENTS.add(RenderListener.class, this);
		EVENTS.add(UpdateListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(GUIRenderListener.class, this);
		EVENTS.remove(RenderListener.class, this);
		EVENTS.remove(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		class_746 player = MC.field_1724;
		
		// check if item is ranged weapon
		class_1799 stack = MC.field_1724.method_31548().method_7391();
		class_1792 item = stack.method_7909();
		if(!(item instanceof class_1753 || item instanceof class_1764))
		{
			target = null;
			return;
		}
		
		// check if using bow
		if(item instanceof class_1753 && !MC.field_1690.field_1904.method_1434()
			&& !player.method_6115())
		{
			target = null;
			return;
		}
		
		// check if crossbow is loaded
		if(item instanceof class_1764 && !class_1764.method_7781(stack))
		{
			target = null;
			return;
		}
		
		// set target
		if(filterEntities(Stream.of(target)) == null)
			target = filterEntities(StreamSupport
				.stream(MC.field_1687.method_18112().spliterator(), true));
		
		if(target == null)
			return;
		
		// set velocity
		velocity = (72000 - player.method_6014()) / 20F;
		velocity = (velocity * velocity + velocity * 2) / 3;
		if(velocity > 1)
			velocity = 1;
		
		// set position to aim at
		double d = RotationUtils.getEyesPos().method_1022(
			target.method_5829().method_1005()) * predictMovement.getValue();
		double posX = target.method_23317() + (target.method_23317() - target.field_6038) * d
			- player.method_23317();
		double posY = target.method_23318() + (target.method_23318() - target.field_5971) * d
			+ target.method_17682() * 0.5 - player.method_23318()
			- player.method_18381(player.method_18376());
		double posZ = target.method_23321() + (target.method_23321() - target.field_5989) * d
			- player.method_23321();
		
		// set yaw
		float neededYaw = (float)Math.toDegrees(Math.atan2(posZ, posX)) - 90;
		MC.field_1724.method_36456(
			RotationUtils.limitAngleChange(MC.field_1724.method_36454(), neededYaw));
		
		// calculate needed pitch
		double hDistance = Math.sqrt(posX * posX + posZ * posZ);
		double hDistanceSq = hDistance * hDistance;
		float g = 0.006F;
		float velocitySq = velocity * velocity;
		float velocityPow4 = velocitySq * velocitySq;
		float neededPitch = (float)-Math.toDegrees(Math.atan((velocitySq - Math
			.sqrt(velocityPow4 - g * (g * hDistanceSq + 2 * posY * velocitySq)))
			/ (g * hDistance)));
		
		// set pitch
		if(Float.isNaN(neededPitch))
			WURST.getRotationFaker()
				.faceVectorClient(target.method_5829().method_1005());
		else
			MC.field_1724.method_36457(neededPitch);
	}
	
	private class_1297 filterEntities(Stream<class_1297> s)
	{
		Stream<class_1297> stream = s.filter(EntityUtils.IS_ATTACKABLE);
		stream = entityFilters.applyTo(stream);
		
		return stream.min(priority.getSelected().comparator).orElse(null);
	}
	
	@Override
	public void onRender(class_4587 matrixStack, float partialTicks)
	{
		if(target == null)
			return;
		
		class_238 box = EntityUtils.getLerpedBox(target, partialTicks)
			.method_989(0, 0.05, 0).method_1014(0.05);
		
		int quadColor = color.getColorI(0.5F * velocity);
		RenderUtils.drawSolidBox(matrixStack, box, quadColor, false);
		
		int lineColor = color.getColorI(0.25F * velocity);
		RenderUtils.drawOutlinedBox(matrixStack, box, lineColor, false);
	}
	
	@Override
	public void onRenderGUI(class_332 context, float partialTicks)
	{
		if(target == null)
			return;
		
		String message;
		if(velocity < 1)
			message = "Charging: " + (int)(velocity * 100) + "%";
		else
			message = "Target Locked";
		
		class_327 tr = MC.field_1772;
		int msgWidth = tr.method_1727(message);
		
		int msgX1 = context.method_51421() / 2 - msgWidth / 2;
		int msgX2 = msgX1 + msgWidth + 3;
		int msgY1 = context.method_51443() / 2 + 1;
		int msgY2 = msgY1 + 10;
		
		// background
		context.method_25294(msgX1, msgY1, msgX2, msgY2, 0x80000000);
		
		// text
		context.method_51433(tr, message, msgX1 + 2, msgY1 + 1, 0xFFFFFFFF, false);
	}
	
	private enum Priority
	{
		DISTANCE("Distance", e -> MC.field_1724.method_5858(e)),
		
		ANGLE("Angle",
			e -> RotationUtils
				.getAngleToLookVec(e.method_5829().method_1005())),
		
		ANGLE_DIST("Angle+Dist",
			e -> Math
				.pow(RotationUtils
					.getAngleToLookVec(e.method_5829().method_1005()), 2)
				+ MC.field_1724.method_5858(e)),
		
		HEALTH("Health", e -> e instanceof class_1309
			? ((class_1309)e).method_6032() : Integer.MAX_VALUE);
		
		private final String name;
		private final Comparator<class_1297> comparator;
		
		private Priority(String name, ToDoubleFunction<class_1297> keyExtractor)
		{
			this.name = name;
			comparator = Comparator.comparingDouble(keyExtractor);
		}
		
		@Override
		public String toString()
		{
			return name;
		}
	}
}
