/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2828;
import net.minecraft.class_2848;
import net.minecraft.class_2848.class_2849;
import net.minecraft.class_634;
import net.minecraft.class_746;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.StopUsingItemListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;

@SearchTags({"arrow dmg", "ArrowDamage", "arrow damage"})
public final class ArrowDmgHack extends Hack implements StopUsingItemListener
{
	private final SliderSetting packets = new SliderSetting("Packets",
		"description.wurst.setting.arrowdmg.packets", 200, 2, 7000, 20,
		ValueDisplay.INTEGER);
	
	private final CheckboxSetting yeetTridents =
		new CheckboxSetting("Trident yeet mode",
			"description.wurst.setting.arrowdmg.trident_yeet_mode", false);
	
	public ArrowDmgHack()
	{
		super("ArrowDMG");
		setCategory(Category.COMBAT);
		addSetting(packets);
		addSetting(yeetTridents);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(StopUsingItemListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(StopUsingItemListener.class, this);
	}
	
	@Override
	public void onStopUsingItem()
	{
		class_746 player = MC.field_1724;
		class_634 netHandler = player.field_3944;
		
		if(!isValidItem(player.method_6047().method_7909()))
			return;
		
		netHandler.method_2883(
			new class_2848(player, class_2849.field_12981));
		
		double x = player.method_23317();
		double y = player.method_23318();
		double z = player.method_23321();
		
		for(int i = 0; i < packets.getValueI() / 2; i++)
		{
			netHandler.method_2883(new class_2828.class_2829(x,
				y - 1e-10, z, true));
			netHandler.method_2883(new class_2828.class_2829(x,
				y + 1e-10, z, false));
		}
	}
	
	private boolean isValidItem(class_1792 item)
	{
		if(yeetTridents.isChecked() && item == class_1802.field_8547)
			return true;
		
		return item == class_1802.field_8102;
	}
}
