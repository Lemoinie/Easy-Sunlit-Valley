/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.wurstclient.Category;
import net.wurstclient.hack.DontSaveState;
import net.wurstclient.hack.Hack;

@DontSaveState
public final class LsdHack extends Hack
{
	public LsdHack()
	{
		super("LSD");
		setCategory(Category.FUN);
	}
	
	@Override
	protected void onEnable()
	{
		if(!(MC.method_1560() instanceof class_1657))
		{
			setEnabled(false);
			return;
		}
		
		if(MC.field_1773.method_3183() != null)
			MC.field_1773.method_3207();
		
		MC.field_1773
			.method_3168(new class_2960("shaders/post/wobble.json"));
	}
	
	@Override
	protected void onDisable()
	{
		if(MC.field_1773.method_3183() != null)
			MC.field_1773.method_3207();
	}
}
