/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1688;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.wurstclient.Category;
import net.wurstclient.ai.PathFinder;
import net.wurstclient.ai.PathPos;
import net.wurstclient.ai.PathProcessor;
import net.wurstclient.commands.PathCmd;
import net.wurstclient.events.RenderListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.DontSaveState;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;
import net.wurstclient.settings.filterlists.EntityFilterList;
import net.wurstclient.settings.filterlists.FollowFilterList;
import net.wurstclient.util.ChatUtils;
import net.wurstclient.util.FakePlayerEntity;

@DontSaveState
public final class FollowHack extends Hack
	implements UpdateListener, RenderListener
{
	private class_1297 entity;
	private EntityPathFinder pathFinder;
	private PathProcessor processor;
	private int ticksProcessing;
	
	private final SliderSetting distance =
		new SliderSetting("Distance", "How closely to follow the target.", 1, 1,
			12, 0.5, ValueDisplay.DECIMAL);
	
	private final CheckboxSetting useAi =
		new CheckboxSetting("Use AI (experimental)", false);
	
	private final EntityFilterList entityFilters = FollowFilterList.create();
	
	public FollowHack()
	{
		super("Follow");
		
		setCategory(Category.MOVEMENT);
		addSetting(distance);
		addSetting(useAi);
		
		entityFilters.forEach(this::addSetting);
	}
	
	@Override
	public String getRenderName()
	{
		if(entity != null)
			return "Following " + entity.method_5477().getString();
		return "Follow";
	}
	
	@Override
	protected void onEnable()
	{
		WURST.getHax().fightBotHack.setEnabled(false);
		WURST.getHax().protectHack.setEnabled(false);
		WURST.getHax().tunnellerHack.setEnabled(false);
		
		if(entity == null)
		{
			Stream<class_1297> stream =
				StreamSupport.stream(MC.field_1687.method_18112().spliterator(), true)
					.filter(e -> !e.method_31481())
					.filter(e -> e instanceof class_1309
						&& ((class_1309)e).method_6032() > 0
						|| e instanceof class_1688)
					.filter(e -> e != MC.field_1724)
					.filter(e -> !(e instanceof FakePlayerEntity));
			
			stream = entityFilters.applyTo(stream);
			
			entity = stream
				.min(Comparator
					.comparingDouble(e -> MC.field_1724.method_5858(e)))
				.orElse(null);
			
			if(entity == null)
			{
				ChatUtils.error("Could not find a valid entity.");
				setEnabled(false);
				return;
			}
		}
		
		pathFinder = new EntityPathFinder();
		EVENTS.add(UpdateListener.class, this);
		EVENTS.add(RenderListener.class, this);
		ChatUtils.message("Now following " + entity.method_5477().getString());
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
		EVENTS.remove(RenderListener.class, this);
		
		pathFinder = null;
		processor = null;
		ticksProcessing = 0;
		PathProcessor.releaseControls();
		
		if(entity != null)
			ChatUtils
				.message("No longer following " + entity.method_5477().getString());
		
		entity = null;
	}
	
	@Override
	public void onUpdate()
	{
		// check if player died
		if(MC.field_1724.method_6032() <= 0)
		{
			if(entity == null)
				ChatUtils.message("No longer following entity");
			setEnabled(false);
			return;
		}
		
		// check if entity died or disappeared
		if(entity.method_31481() || entity instanceof class_1309
			&& ((class_1309)entity).method_6032() <= 0)
		{
			entity = StreamSupport
				.stream(MC.field_1687.method_18112().spliterator(), true)
				.filter(class_1309.class::isInstance)
				.filter(
					e -> !e.method_31481() && ((class_1309)e).method_6032() > 0)
				.filter(e -> e != MC.field_1724)
				.filter(e -> !(e instanceof FakePlayerEntity))
				.filter(e -> entity.method_5477().getString()
					.equalsIgnoreCase(e.method_5477().getString()))
				.min(Comparator
					.comparingDouble(e -> MC.field_1724.method_5858(e)))
				.orElse(null);
			
			if(entity == null)
			{
				ChatUtils.message("No longer following entity");
				setEnabled(false);
				return;
			}
			
			pathFinder = new EntityPathFinder();
			processor = null;
			ticksProcessing = 0;
		}
		
		if(useAi.isChecked())
		{
			// reset pathfinder
			if((processor == null || processor.isDone() || ticksProcessing >= 10
				|| !pathFinder.isPathStillValid(processor.getIndex()))
				&& (pathFinder.isDone() || pathFinder.isFailed()))
			{
				pathFinder = new EntityPathFinder();
				processor = null;
				ticksProcessing = 0;
			}
			
			// find path
			if(!pathFinder.isDone() && !pathFinder.isFailed())
			{
				PathProcessor.lockControls();
				WURST.getRotationFaker()
					.faceVectorClient(entity.method_5829().method_1005());
				pathFinder.think();
				pathFinder.formatPath();
				processor = pathFinder.getProcessor();
			}
			
			// process path
			if(!processor.isDone())
			{
				processor.process();
				ticksProcessing++;
			}
		}else
		{
			// jump if necessary
			if(MC.field_1724.field_5976 && MC.field_1724.method_24828())
				MC.field_1724.method_6043();
			
			// swim up if necessary
			if(MC.field_1724.method_5799() && MC.field_1724.method_23318() < entity.method_23318())
				MC.field_1724.method_18799(MC.field_1724.method_18798().method_1031(0, 0.04, 0));
			
			// control height if flying
			if(!MC.field_1724.method_24828()
				&& (MC.field_1724.method_31549().field_7479
					|| WURST.getHax().flightHack.isEnabled())
				&& MC.field_1724.method_5649(entity.method_23317(), MC.field_1724.method_23318(),
					entity.method_23321()) <= MC.field_1724.method_5649(
						MC.field_1724.method_23317(), entity.method_23318(), MC.field_1724.method_23321()))
			{
				if(MC.field_1724.method_23318() > entity.method_23318() + 1D)
					MC.field_1690.field_1832.method_23481(true);
				else if(MC.field_1724.method_23318() < entity.method_23318() - 1D)
					MC.field_1690.field_1903.method_23481(true);
			}else
			{
				MC.field_1690.field_1832.method_23481(false);
				MC.field_1690.field_1903.method_23481(false);
			}
			
			// follow entity
			WURST.getRotationFaker()
				.faceVectorClient(entity.method_5829().method_1005());
			double distanceSq = Math.pow(distance.getValue(), 2);
			MC.field_1690.field_1894
				.method_23481(MC.field_1724.method_5649(entity.method_23317(),
					MC.field_1724.method_23318(), entity.method_23321()) > distanceSq);
		}
	}
	
	@Override
	public void onRender(class_4587 matrixStack, float partialTicks)
	{
		PathCmd pathCmd = WURST.getCmds().pathCmd;
		pathFinder.renderPath(matrixStack, pathCmd.isDebugMode(),
			pathCmd.isDepthTest());
	}
	
	public void setEntity(class_1297 entity)
	{
		this.entity = entity;
	}
	
	private class EntityPathFinder extends PathFinder
	{
		public EntityPathFinder()
		{
			super(class_2338.method_49638(entity.method_19538()));
			setThinkTime(1);
		}
		
		@Override
		protected boolean checkDone()
		{
			class_243 center = class_243.method_24953(current);
			double distanceSq = Math.pow(distance.getValue(), 2);
			return done = entity.method_5707(center) <= distanceSq;
		}
		
		@Override
		public ArrayList<PathPos> formatPath()
		{
			if(!done)
				failed = true;
			
			return super.formatPath();
		}
	}
}
