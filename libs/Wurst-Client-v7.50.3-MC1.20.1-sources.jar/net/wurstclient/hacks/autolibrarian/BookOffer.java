/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.autolibrarian;

import java.util.Objects;
import net.minecraft.class_1887;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.wurstclient.WurstClient;
import net.wurstclient.WurstTranslator;

public record BookOffer(String id, int level, int price)
	implements Comparable<BookOffer>
{
	public static BookOffer create(class_1887 enchantment)
	{
		class_2960 id = class_7923.field_41176.method_10221(enchantment);
		return new BookOffer("" + id, enchantment.method_8183(), 64);
	}
	
	public class_1887 getEnchantment()
	{
		return class_7923.field_41176.method_10223(new class_2960(id));
	}
	
	public String getEnchantmentName()
	{
		WurstTranslator translator = WurstClient.INSTANCE.getTranslator();
		class_1887 enchantment = getEnchantment();
		return translator.translateMcEnglish(enchantment.method_8184());
	}
	
	public String getEnchantmentNameWithLevel()
	{
		WurstTranslator translator = WurstClient.INSTANCE.getTranslator();
		class_1887 enchantment = getEnchantment();
		String name =
			translator.translateMcEnglish(enchantment.method_8184());
		
		if(enchantment.method_8183() > 1)
			name += " "
				+ translator.translateMcEnglish("enchantment.level." + level);
		
		return name;
	}
	
	public String getFormattedPrice()
	{
		return price + " emerald" + (price == 1 ? "" : "s");
	}
	
	public boolean isValid()
	{
		class_1887 enchantment = getEnchantment();
		return enchantment != null
			&& enchantment.method_25949() && level >= 1
			&& level <= enchantment.method_8183() && price >= 1 && price <= 64;
	}
	
	@Override
	public int compareTo(BookOffer other)
	{
		int idCompare = id.compareTo(other.id);
		if(idCompare != 0)
			return idCompare;
		
		return Integer.compare(level, other.level);
	}
	
	@Override
	public boolean equals(Object obj)
	{
		if(this == obj)
			return true;
		
		if(obj == null || getClass() != obj.getClass())
			return false;
		
		BookOffer other = (BookOffer)obj;
		return id.equals(other.id) && level == other.level;
	}
	
	@Override
	public int hashCode()
	{
		return Objects.hash(id, level);
	}
}
