/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.EnumSetting;
import net.wurstclient.util.ChatUtils;
import net.wurstclient.util.InventoryUtils;

@SearchTags({"troll potion", "TrollingPotion", "trolling potion"})
public final class TrollPotionHack extends Hack
{
	private final EnumSetting<PotionType> potionType =
		new EnumSetting<>("Potion type", "The type of potion to generate.",
			PotionType.values(), PotionType.SPLASH);
	
	public TrollPotionHack()
	{
		super("TrollPotion");
		setCategory(Category.ITEMS);
		addSetting(potionType);
	}
	
	@Override
	protected void onEnable()
	{
		// check gamemode
		if(!MC.field_1724.method_31549().field_7477)
		{
			ChatUtils.error("Creative mode only.");
			setEnabled(false);
			return;
		}
		
		// generate potion
		class_1799 stack = potionType.getSelected().createPotionStack();
		
		// give potion
		class_1661 inventory = MC.field_1724.method_31548();
		int slot = inventory.method_7376();
		if(slot < 0)
			ChatUtils.error("Cannot give potion. Your inventory is full.");
		else
		{
			InventoryUtils.setCreativeStack(slot, stack);
			ChatUtils.message("Potion created.");
		}
		
		setEnabled(false);
	}
	
	private enum PotionType
	{
		NORMAL("Normal", "Potion", class_1802.field_8574),
		
		SPLASH("Splash", "Splash Potion", class_1802.field_8436),
		
		LINGERING("Lingering", "Lingering Potion", class_1802.field_8150),
		
		ARROW("Arrow", "Arrow", class_1802.field_8087);
		
		private final String name;
		private final String itemName;
		private final class_1792 item;
		
		private PotionType(String name, String itemName, class_1792 item)
		{
			this.name = name;
			this.itemName = itemName;
			this.item = item;
		}
		
		@Override
		public String toString()
		{
			return name;
		}
		
		public class_1799 createPotionStack()
		{
			class_1799 stack = new class_1799(item);
			
			class_2499 effects = new class_2499();
			for(int i = 1; i <= 23; i++)
			{
				class_2487 effect = new class_2487();
				effect.method_10569("Amplifier", Integer.MAX_VALUE);
				effect.method_10569("Duration", Integer.MAX_VALUE);
				effect.method_10569("Id", i);
				effects.add(effect);
			}
			
			class_2487 nbt = new class_2487();
			nbt.method_10566("CustomPotionEffects", effects);
			stack.method_7980(nbt);
			
			String name = "\u00a7f" + itemName + " of Trolling";
			stack.method_7977(class_2561.method_43470(name));
			
			return stack;
		}
	}
}
