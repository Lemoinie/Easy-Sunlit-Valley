/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.options;

import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

public final class EnterProfileNameScreen extends class_437
{
	private final class_437 prevScreen;
	private final Consumer<String> callback;
	
	private class_342 valueField;
	private class_4185 doneButton;
	
	public EnterProfileNameScreen(class_437 prevScreen, Consumer<String> callback)
	{
		super(class_2561.method_43470(""));
		this.prevScreen = prevScreen;
		this.callback = callback;
	}
	
	@Override
	public void method_25426()
	{
		int x1 = field_22789 / 2 - 100;
		int y1 = 60;
		int y2 = field_22790 / 3 * 2;
		
		class_327 tr = field_22787.field_1772;
		
		valueField = new class_342(tr, x1, y1, 200, 20, class_2561.method_43470(""));
		valueField.method_1852("");
		valueField.method_1875(0);
		
		method_25429(valueField);
		method_25395(valueField);
		valueField.method_25365(true);
		
		doneButton = class_4185.method_46430(class_2561.method_43470("Done"), b -> done())
			.method_46434(x1, y2, 200, 20).method_46431();
		method_37063(doneButton);
	}
	
	private void done()
	{
		String value = valueField.method_1882();
		if(!value.isEmpty())
			callback.accept(value);
		
		field_22787.method_1507(prevScreen);
	}
	
	@Override
	public boolean method_25404(int keyCode, int scanCode, int int_3)
	{
		switch(keyCode)
		{
			case GLFW.GLFW_KEY_ENTER:
			done();
			break;
			
			case GLFW.GLFW_KEY_ESCAPE:
			field_22787.method_1507(prevScreen);
			break;
		}
		
		return super.method_25404(keyCode, scanCode, int_3);
	}
	
	@Override
	public void method_25393()
	{
		valueField.method_1865();
	}
	
	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY,
		float partialTicks)
	{
		method_25420(context);
		context.method_25300(field_22787.field_1772,
			"Name your new profile", field_22789 / 2, 20, 0xFFFFFF);
		
		valueField.method_25394(context, mouseX, mouseY, partialTicks);
		super.method_25394(context, mouseX, mouseY, partialTicks);
	}
	
	@Override
	public boolean method_25421()
	{
		return false;
	}
	
	@Override
	public boolean method_25422()
	{
		return false;
	}
}
